document.getElementById('profileForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Impede o envio do formulário
  
    // Obtém os valores dos campos
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var dateOfBirth = document.getElementById('dateOfBirth').value;
    var gender = document.getElementById('gender').value;
    var bio = document.getElementById('bio').value;
    var profilePic = document.getElementById('profilePic').files[0];
  
    // Cria um objeto FormData para enviar os dados do formulário, incluindo a foto
    var formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('dateOfBirth', dateOfBirth);
    formData.append('gender', gender);
    formData.append('bio', bio);
    formData.append('profilePic', profilePic);
  
    // Salva os dados do usuário no armazenamento (por exemplo, enviar para um servidor ou salvar em um banco de dados)
    // Neste exemplo, apenas exibiremos os dados e a foto na página
    displayUserData(formData);
  });
  function displayUserData(formData) {
    var userData = document.createElement('div');
    userData.innerHTML = '<h2>Dados do Usuário</h2>' +
                          '<p><strong>Nome:</strong> ' + formData.get('name') + '</p>' +
                          '<p><strong>Email:</strong> ' + formData.get('email') + '</p>' +
                          '<p><strong>Data de Nascimento:</strong> ' + formData.get('dateOfBirth') + '</p>' +
                          '<p><strong>Gênero:</strong> ' + formData.get('gender') + '</p>' +
                          '<p><strong>Biografia:</strong> ' + formData.get('bio') + '</p>';
  
    var profilePic = document.createElement('img');
    profilePic.src = URL.createObjectURL(formData.get('profilePic'));
    profilePic.id = 'uploadedProfilePic';
  
    var existingProfilePic = document.getElementById('uploadedProfilePic');
    if (existingProfilePic) {
      existingProfilePic.parentNode.removeChild(existingProfilePic);
    }
  
    document.getElementById('profilePicture').appendChild(profilePic);
    document.body.appendChild(userData);
  }
  
  // Funções adicionadas para as funcionalidades extras
  
  // Conquistas
  var achievements = [];
  
  function addAchievement(achievement) {
    achievements.push(achievement);
  }
  
  function displayAchievements() {
    var achievementsDiv = document.createElement('div');
    achievementsDiv.innerHTML = '<h3>Minhas Conquistas</h3>';
  
    for (var i = 0; i < achievements.length; i++) {
      var achievement = achievements[i];
      var achievementItem = document.createElement('p');
      achievementItem.innerText = achievement;
      achievementsDiv.appendChild(achievementItem);
    }
  
    document.getElementById('achievements').appendChild(achievementsDiv);
  }
  
  // Barra de Progressão
  function updateProgressBar(progress) {
    var progressBar = document.getElementById('progressBar');
    progressBar.style.width = progress + '%';
    progressBar.innerText = progress + '%';
  }
  
  // Pontos
  var points = 0;
  
  function addPoints(amount) {
    points += amount;
    document.getElementById('points').innerText = 'Pontos: ' + points;
  }
  
  // Atividades
  var exercisesDone = 0;
  var exercisesTotal = 10;
  
  function updateActivities() {
    document.getElementById('exercisesDone').innerText = 'Exercícios feitos: ' + exercisesDone;
    document.getElementById('exercisesRemaining').innerText = 'Exercícios restantes: ' + (exercisesTotal - exercisesDone);
  }
  
  // Exemplo de uso
  addAchievement('Conquista 1');
  addAchievement('Conquista 2');
  addAchievement('Conquista 3');
  
  displayAchievements();
  
  updateProgressBar(50);
  
  addPoints(100);
  
  exercisesDone = 5;
  updateActivities();
  document.getElementById('profile-tab').addEventListener('click', function() {
    var profileTab = document.getElementById('profile-tab');
    var achievementsTab = document.getElementById('achievements-tab');
    var activitiesTab = document.getElementById('activities-tab');
    var profilePanel = document.getElementById('profile');
    var achievementsPanel = document.getElementById('achievements');
    var activitiesPanel = document.getElementById('activities');

    // Remove as classes "active" dos elementos não selecionados
    achievementsTab.classList.remove('active');
    activitiesTab.classList.remove('active');
    achievementsPanel.classList.remove('active', 'show');
    activitiesPanel.classList.remove('active', 'show');

    // Adiciona as classes "active" nos elementos selecionados
    profileTab.classList.add('active');
    profilePanel.classList.add('active', 'show');
  });

  document.getElementById('achievements-tab').addEventListener('click', function() {
    var profileTab = document.getElementById('profile-tab');
    var achievementsTab = document.getElementById('achievements-tab');
    var activitiesTab = document.getElementById('activities-tab');
    var profilePanel = document.getElementById('profile');
    var achievementsPanel = document.getElementById('achievements');
    var activitiesPanel = document.getElementById('activities');

    // Remove as classes "active" dos elementos não selecionados
    profileTab.classList.remove('active');
    activitiesTab.classList.remove('active');
    profilePanel.classList.remove('active', 'show');
    activitiesPanel.classList.remove('active', 'show');

    // Adiciona as classes "active" nos elementos selecionados
    achievementsTab.classList.add('active');
    achievementsPanel.classList.add('active', 'show');
  });

  document.getElementById('activities-tab').addEventListener('click', function() {
    var profileTab = document.getElementById('profile-tab');
    var achievementsTab = document.getElementById('achievements-tab');
    var activitiesTab = document.getElementById('activities-tab');
    var profilePanel = document.getElementById('profile');
    var achievementsPanel = document.getElementById('achievements');
    var activitiesPanel = document.getElementById('activities');

    // Remove as classes "active" dos elementos não selecionados
    profileTab.classList.remove('active');
    achievementsTab.classList.remove('active');
    profilePanel.classList.remove('active', 'show');
    achievementsPanel.classList.remove('active', 'show');

    // Adiciona as classes "active" nos elementos selecionados
    activitiesTab.classList.add('active');
    activitiesPanel.classList.add('active', 'show');
  });
