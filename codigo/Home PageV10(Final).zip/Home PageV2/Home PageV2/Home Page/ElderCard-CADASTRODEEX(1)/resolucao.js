window.onload = function() {
    updateExerciseList();
};

function updateExerciseList() {
    let exercises = JSON.parse(localStorage.getItem('exercises')); // Carrega a lista de exercícios do localStorage
    let exerciseList = document.getElementById('exerciseList'); // Obtém o elemento da lista de exercícios
    exerciseList.innerHTML = ''; // Limpa a lista de exercícios

    if (exercises) {
        exercises.forEach(function(exercise, index) { // Para cada exercício
            let exerciseElement = document.createElement('div'); // Cria um novo elemento div
            exerciseElement.className = 'exercise'; // Define a classe do elemento para 'exercise'

            // Adiciona o nome do exercício ao elemento
            let nameElement = document.createElement('h2');
            nameElement.textContent = exercise.name;
            exerciseElement.appendChild(nameElement);

            // Adiciona um botão para iniciar o exercício ao elemento
            let startButton = document.createElement('button');
            startButton.textContent = 'Iniciar exercício';
            startButton.addEventListener('click', function() { startExercise(index); }); // Adiciona um event listener para a ação de clique
            exerciseElement.appendChild(startButton);

            // Adiciona o elemento à lista de exercícios
            exerciseList.appendChild(exerciseElement);
        });
    }
}

function startExercise(index) {
    let exercises = JSON.parse(localStorage.getItem('exercises'));
    let exercise = exercises[index];
    let exerciseList = document.getElementById('exerciseList');
    exerciseList.innerHTML = 
    `<h2>${exercise.name}</h2>
    <p>${exercise.description}</p>
    <form id="answerForm">
        <input type="radio" id="option1" name="answer" value="1">
        <label for="option1">${exercise.options[0]}</label><br>
        <input type="radio" id="option2" name="answer" value="2">
        <label for="option2">${exercise.options[1]}</label><br>
        <input type="radio" id="option3" name="answer" value="3">
        <label for="option3">${exercise.options[2]}</label><br>
        <input type="radio" id="option4" name="answer" value="4">
        <label for="option4">${exercise.options[3]}</label><br>
        <button type="button" onclick="checkAnswer(${index})">Verificar resposta</button>
    </form>
    <button onclick="updateExerciseList()">Voltar</button>`;
}

function checkAnswer(index) {
    let exercises = JSON.parse(localStorage.getItem('exercises'));
    let exercise = exercises[index];
    let userAnswer = document.querySelector('input[name="answer"]:checked');

    if (userAnswer) {
        userAnswer = Number(userAnswer.value);
        if (exercise.correctAnswer === userAnswer) {
            alert('Parabéns! Sua resposta está correta!');
        } else {
            alert('Desculpe, sua resposta está incorreta. Tente novamente!');
        }
    } else {
        alert('Por favor, selecione uma resposta antes de verificar.');
    }
}



