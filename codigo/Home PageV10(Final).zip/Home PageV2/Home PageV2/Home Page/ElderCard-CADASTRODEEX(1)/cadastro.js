document.getElementById('exerciseForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const description = document.getElementById('description').value;
    const option1 = document.getElementById('option1').value;
    const option2 = document.getElementById('option2').value;
    const option3 = document.getElementById('option3').value;
    const option4 = document.getElementById('option4').value;
    const correctAnswer = Number(document.getElementById('correctAnswer').value);




    const exercise = {
        name: name,
        description: description,
        options: [option1, option2, option3, option4],
        correctAnswer: correctAnswer
    };

    let exercises = JSON.parse(localStorage.getItem('exercises'));
    if (!exercises) {
        exercises = [];
    }
    exercises.push(exercise);
    localStorage.setItem('exercises', JSON.stringify(exercises));
    updateExercisesList();
});



// Código existente para excluir um exercício
function deleteExercise(index) {
    let exercises = JSON.parse(localStorage.getItem('exercises'));
    exercises.splice(index, 1);
    localStorage.setItem('exercises', JSON.stringify(exercises));
    updateExercisesList();
}

// Código existente para atualizar a lista de exercícios
function updateExercisesList() {
    let exercises = JSON.parse(localStorage.getItem('exercises'));
    let exercisesDiv = document.getElementById('exercises');
    exercisesDiv.innerHTML = '';
    if (exercises) {
        exercises.forEach(function(exercise, index) {
            let exerciseElement = document.createElement('p');
            exerciseElement.textContent = exercise.name; // Apenas o nome do exercício será exibido.
            let deleteButton = document.createElement('button');
            deleteButton.textContent = 'Excluir';
            deleteButton.addEventListener('click', function() { deleteExercise(index); });
            exerciseElement.appendChild(deleteButton);
            exercisesDiv.appendChild(exerciseElement);
        });
    }
}

// Código existente para carregar a lista de exercícios no carregamento da página
window.onload = function() {
    updateExercisesList();
};
