***A PAGINA SPRINT3.HTML, ACESSA O LOCAL STORAGE PARA EXIBIR OS VIDEOS CADASTRADOS NA PAGINA SPRINT2.HTML***

***COLAR O CAMINHO DOS VIDEOS NA PASTA, NAO COM URLS DO YOUTUBE***

-Como usar o botão editar:
-sempre abrir o index com o live server do VScode
-Para editar o video, copiar o caminho do video .mp4 dentro da pasta do index.html, com o vscode aberto em "copy relative path"(INDISPENSÁVEL)
-ao clicar em editar, colar o caminho do video copiado DENTRO DO VSCODE, com COPY RALATIVE PATH no quadro que aparecer

-REPLIT: https://tiaw--talesrochamorei.repl.co