window.onload = function() {
  var videoPlayer = document.getElementById("videoPlayer"); // Elemento de vídeo na página do usuário

  // Obtém o caminho do vídeo armazenado no localStorage
  var videoPath = localStorage.getItem("videoPath");

  if (videoPath) {
    // Cria um elemento source e atribui o caminho do vídeo a ele
    var source = document.createElement("source");
    source.src = videoPath;
    source.type = "video/mp4";

    // Limpa o conteúdo do elemento de vídeo e adiciona o source
    videoPlayer.innerHTML = '';
    videoPlayer.appendChild(source);
  }
};
