function editVideo(videoPlayerID) {
  var videoUrl = prompt("Insira o caminho do video NA PASTA(copiado no vscode como 'copy path') do novo vídeo (ou deixe em branco para remover):");
  var videoElement = document.getElementById(videoPlayerID);
  

  if (videoUrl) {
    videoElement.src = videoUrl;
    localStorage.setItem(videoPlayerID, videoUrl);
    
  }
}

window.onload = function() {
  var videoPlayers = document.getElementsByTagName("video");
  for (var i = 0; i < videoPlayers.length; i++) {
    var videoPlayer = videoPlayers[i];
    var videoPlayerId = videoPlayer.getAttribute("id");

    var videoPath = localStorage.getItem(videoPlayerId);
    if (videoPath) {
      var source = document.createElement("source");
      source.src = videoPath;
      source.type = "video/mp4";

      videoPlayer.innerHTML = '';
      videoPlayer.appendChild(source);
    }
  }
}
